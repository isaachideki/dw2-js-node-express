// console.log - Imprime algo no temrinal
// Comentário em linha
/*
comentario em bloco
*/
console.log("Hello World! meu primeiro arquivo.")