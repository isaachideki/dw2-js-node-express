const valorMetade = prompt("Digite um número:");
const calcularMetade = (n) => {
  return n / 2;
};
document.write(`<p>A metade do número digitado é: <strong>${calcularMetade(valorMetade)}</strong></p>`);
