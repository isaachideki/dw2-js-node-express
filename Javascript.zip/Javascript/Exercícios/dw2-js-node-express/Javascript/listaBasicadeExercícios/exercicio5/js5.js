
const iife = function(){
    document.write("<p>Calculadora Universal pronta para uso!</p>");
}();