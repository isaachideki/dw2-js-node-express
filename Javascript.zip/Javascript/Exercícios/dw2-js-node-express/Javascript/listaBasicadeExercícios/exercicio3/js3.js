const valorDobro = prompt("Digite um número:");
const calcularDobro = (n) => {
  return n * 2;
};
document.write(`<p>O dobro do número digitado é: <strong>${calcularDobro(valorDobro)}</strong></p>`);

